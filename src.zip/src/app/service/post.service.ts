import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  url = "https://jsonplaceholder.typicode.com/posts"
  constructor(private http: HttpClient) { }
  httpheader() {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8' }) };
    return httpOptions;
  }
  getPost() {
    return this.http.get(this.url);
  }
 
  updatePost(obj) {
    var postData = JSON.stringify(obj);
    return this.http.put(this.url + '/' + obj.id, postData, this.httpheader());
  }
  savePost(obj) {
    var postData = JSON.stringify(obj);
    return this.http.post(this.url, postData, this.httpheader());
  }
  deletePost(obj) {
    return this.http.delete(this.url + '/' + obj.id);
  }
}
