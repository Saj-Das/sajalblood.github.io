import { Component, OnInit } from '@angular/core';
import { PostService } from '../service/post.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
  providers: [PostService]
})
export class PostComponent implements OnInit {
  postList: any;
  postObj: {id:0,userId:0,title:"",body:""};
  type = "list";
  msg = ""
  constructor(private postService: PostService) { }

  ngOnInit() {
    this.postService.getPost().subscribe(x => {
      this.postList = x;
    })
  }
  edit(obj) {
    this.postObj = this.postList.filter(x => x.id == obj.id)[0];
    this.type = "detail"
    
  }
  updateData() {
    this.postService.updatePost(this.postObj).subscribe(x => {
      this.msg = "updated"
    }, error => { this.msg = "not updated" }
    )
  }
  AddData()
  {if(this.postObj.id!=0)
    {
      this.postService.savePost(this.postObj).subscribe(x => {
        this.msg = "Added"
      }, error => { this.msg = "not Added" }
      )
    }
    else
    { this.msg = "not Added" }
  }
  goToPage(pageType)
  {this.msg=""
    this.type = pageType;
    if(pageType=='Add')
    {
      this.postObj={id:0,userId:0,title:"",body:""};
    }
  }
}
